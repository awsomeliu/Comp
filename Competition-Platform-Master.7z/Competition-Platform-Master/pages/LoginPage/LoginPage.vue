<template>
	<view class="=container">
		<view class="title">
			门头沟
		</view>
	</view>
</template>

<script>
</script>

<style>
	.=container{
		border: 1rpx;
		border-color: black;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		height: 100vh;
	}
	.title{
		font-size: 24px;
		margin-bottom: 20px;
	}
</style>